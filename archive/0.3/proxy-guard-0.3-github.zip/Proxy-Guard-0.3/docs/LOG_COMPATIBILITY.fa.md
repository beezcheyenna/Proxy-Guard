# سازگاری گزارش زمان اجرا

[English](LOG_COMPATIBILITY.md) · [简体中文](LOG_COMPATIBILITY.zh-CN.md) · [日本語](LOG_COMPATIBILITY.ja.md) · [Русский](LOG_COMPATIBILITY.ru.md) · [فارسی](LOG_COMPATIBILITY.fa.md)

<div dir="rtl" lang="fa">

LuCI از چینی ساده‌شده، انگلیسی، ژاپنی، روسی و فارسی پشتیبانی می‌کند. شناسایی گزارش به پیام‌های اصلی و قالب‌های بررسی‌شدهٔ هر کلاینت وابسته است.

## کلاینت‌ها و پیام‌های بررسی‌شده

| کلاینت | قالب شناخته‌شده | زبان‌های بازبینی‌شده |
| --- | --- | --- |
| PassWall | `YYYY-MM-DD HH:MM:SS: message` | پیام‌های ثابت چینی دربارهٔ چرخهٔ اجرا و شناسه‌های قدیمی. |
| PassWall2 | `YYYY-MM-DD HH:MM:SS: message` | پیام‌های چرخهٔ اجرا به انگلیسی، چینی ساده‌شده و سنتی، روسی و فارسی. |
| OpenClash | `YYYY-MM-DD HH:MM:SS [level] message` | شناسه‌های انگلیسی بررسی‌شده و پیام‌های بارگذاری مجدد پویا برای فایروال. |
| Nikki | `[YYYY-MM-DD HH:MM:SS] [component] message` | شناسه‌های انگلیسی App/Core/Proxy/Profile و پیام‌های شروع با تأخیر. |
| HomeProxy | `YYYY-MM-DD HH:MM:SS [DAEMON] message` | شناسه‌های انگلیسی بررسی‌شده و پیام پایان راه‌اندازی sing-box همراه نسخه. |

بازبینی‌های منبع به شرح زیرند.

- [PassWall — 5e2bbfa8](https://github.com/Openwrt-Passwall/openwrt-passwall/tree/5e2bbfa8e6a32f7e54a7fe29891a28fb05439e52)
- [PassWall2 — 896c586a](https://github.com/Openwrt-Passwall/openwrt-passwall2/tree/896c586a27c9a7c0b9e3d75b631965dea86b9945)
- [OpenClash — e553e82e](https://github.com/vernesong/OpenClash/tree/e553e82e01c697aefbe1555261a503f425e00ccd)
- [Nikki — 78e1a751](https://github.com/nikkinikki-org/OpenWrt-nikki/tree/78e1a751d55ed0762811f054ee699049473da7b8)
- [HomeProxy — fadaa676](https://github.com/immortalwrt/homeproxy/tree/fadaa676104f59ff6ace480a780a258d846d0aec)

فهرست‌های PassWall و PassWall2 با منبع انتشار **26.11.3-1** نیز بازتولید شدند. ۵۵ الگوی دقیق و ۷۴ نمونهٔ آزمون بازگشتی یکسان‌اند. OpenClash 0.48.002 و HomeProxy این دور مطابق بازبینی‌های بالایند. Nikki 1.26.2 همان پیام‌های شناخته‌شده را می‌نویسد. رابط ژاپنی می‌تواند پیام‌های اصلی پشتیبانی‌شده، از جمله چینی و انگلیسی، را تشخیص دهد. شاخه‌ها، ترجمه‌ها و متن‌های آینده نیاز به بررسی جداگانه دارند.

[PassWall 0b969d5a](https://github.com/Openwrt-Passwall/openwrt-passwall/tree/0b969d5a49743a9725c8dc283b01753c5217dd0d) · [PassWall2 176e27cb](https://github.com/Openwrt-Passwall/openwrt-passwall2/tree/176e27cb8d9852ce9b30d2e180810b544d8fc9dc)

## فعال شدن محافظت و بازیابی

پایش گزارش در تنظیمات پایش سرویس کلاینت جداگانه فعال می‌شود. پیام معتبر راه‌اندازی مجدد، حذف، پاک‌سازی یا بارگیری قانون‌ها، توقف و خرابی کلی راه‌اندازی می‌تواند محافظت را فعال کند. زمان‌بندی کار، دانلود، به‌روزرسانی معمول، کوتاه‌شدن فایل گزارش و خطای گرهٔ فرعی به‌تنهایی نشان توقف پروکسی اصلی نیستند.

برای بازیابی به پیام تازهٔ پایان راه‌اندازی کلی در چرخهٔ جاری، آمادگی سرویس‌ها و آزمون تازهٔ موفق پروکسی نیاز است. لغو می‌تواند راه‌اندازی در صف را کنار بگذارد. قانون‌های حذف‌شده و انتظار مسدودسازی که در پایش تقویت‌شده آغاز شده طبق روال عادی رسیدگی می‌شوند.

## زمان، حد خواندن و دامنهٔ تشخیص

برچسب زمان با منطقهٔ زمانی محلی روتر تفسیر می‌شود. اختلاف ثابت UTC برای زمان‌بندی جداست. تأخیر با ساعت یکنواخت سنجیده می‌شود. هر دور حداکثر ۶۴ KiB با پشتیبانی از CRLF، خط ناقص، کوتاه‌شدن و چرخش فایل خوانده می‌شود. قالب ناشناخته، زمان نامعتبر یا آینده و نبود گزارش را بررسی کنید. نمونه‌برداری تنها پیام نوشته‌شده را می‌بیند و تغییر کوتاه میان دو دور ممکن است دیده نشود.

پایش سرویس، تطبیق گزارش و بررسی اتصال مستقل‌اند. یافتن پیام، سلامت فرایند، شنونده یا مسیر پروکسی را تأیید نمی‌کند. [سازگاری](COMPATIBILITY.fa.md) و [رفتار بررسی](USAGE.fa.md) را ببینید.

## منابع و نمونه‌های آزمون

منشأ و نمونه‌های PassWall/PassWall2 در `tests/passwall_log_corpus.json` هستند. `tools/sync_passwall_log_messages.py` منبع ثابت و فهرست را بدون اجرای اسکریپت‌های بالادست می‌خواند. الگوهای دیگر در `package/root/usr/lib/proxy-guard/passwall-log.uc` قرار دارند. `tests/client_adapters_test.uc`، `tests/passwall_log_languages.uc` و `tests/passwall_log_test.uc` پیام‌های معتبر، راه‌اندازی چندزبانه، پیام قدیمی یا آینده، لغو، متن نامعتبر و تغییر فهرست را بررسی می‌کنند. مطالب مشتق‌شده مجوز بالادست را حفظ می‌کنند. [اطلاعیه‌های ثالث](THIRD_PARTY_NOTICES.fa.md) را ببینید.

</div>
